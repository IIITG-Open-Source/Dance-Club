package com.example.dancewebsite

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
